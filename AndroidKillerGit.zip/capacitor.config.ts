import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.killerpool.app',
  appName: 'Killer',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
